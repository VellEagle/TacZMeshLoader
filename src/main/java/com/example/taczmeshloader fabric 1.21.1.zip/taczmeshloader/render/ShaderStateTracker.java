package com.example.taczmeshloader.render;

import com.example.taczmeshloader.core.PolyMeshModel;
import com.tacz.guns.compat.iris.IrisCompat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * Iris のシェーダーパック切り替えを検知し、全 {@link PolyMeshModel} の
 * VBO キャッシュを無効化するトラッカー。
 *
 * NeoForge 版との対応:
 *   @EventBusSubscriber + RenderGuiEvent.Pre
 *   → HudRenderCallback.EVENT (Fabric)
 */
@Environment(EnvType.CLIENT)
public final class ShaderStateTracker {

    private static final boolean IRIS_LOADED =
            FabricLoader.getInstance().isModLoaded("iris");

    private static Boolean lastShaderState = null;

    private static final Set<PolyMeshModel> registeredModels =
            Collections.newSetFromMap(new WeakHashMap<>());

    private ShaderStateTracker() {}

    /** TacZMeshLoaderMod から呼ばれ、Fabric のイベントシステムに登録する */
    public static void register() {
        // HudRenderCallback は毎フレームのHUD描画前に呼ばれる（RenderGuiEvent.Pre 相当）
        HudRenderCallback.EVENT.register((guiGraphics, tickDelta) -> {
            if (!IRIS_LOADED) return;
            if (registeredModels.isEmpty()) return;

            boolean currentState = IrisCompat.isUsingRenderPack();

            if (lastShaderState == null) {
                lastShaderState = currentState;
                return;
            }

            if (lastShaderState != currentState) {
                lastShaderState = currentState;
                for (PolyMeshModel model : registeredModels) {
                    model.invalidateVboCache();
                }
            }
        });
    }

    public static void registerModel(PolyMeshModel model) {
        if (model != null) {
            registeredModels.add(model);
        }
    }

    public static void unregisterModel(PolyMeshModel model) {
        registeredModels.remove(model);
    }
}
